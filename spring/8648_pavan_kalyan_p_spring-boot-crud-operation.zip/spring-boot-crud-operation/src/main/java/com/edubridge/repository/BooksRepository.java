package com.edubridge.repository;

import org.springframework.data.repository.CrudRepository;
import com.edubridge.model.Books;
//repository that extends CrudRepository
public interface BooksRepository extends CrudRepository<Books, Integer>
{
}
