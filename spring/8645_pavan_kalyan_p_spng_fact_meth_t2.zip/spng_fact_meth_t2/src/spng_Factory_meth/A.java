package spng_Factory_meth;

public class A implements Printable{
@Override
public void print() {
System.out.println("hello a");
}
}
