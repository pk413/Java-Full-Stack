package spng_Factory_meth;

public interface Printable {
void print();
}
