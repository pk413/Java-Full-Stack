package spng_Factory_meth;

public class PrintableFactory {
	public static Printable getPrintable(){
		//return new B();
		return new A();//return any one instance, either A or B
		}
		}