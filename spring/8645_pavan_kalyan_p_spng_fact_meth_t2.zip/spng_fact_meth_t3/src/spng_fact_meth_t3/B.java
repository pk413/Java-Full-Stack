package spng_fact_meth_t3;

public class B implements Printable{
@Override
public void print() {
System.out.println("hello b");
}
}

