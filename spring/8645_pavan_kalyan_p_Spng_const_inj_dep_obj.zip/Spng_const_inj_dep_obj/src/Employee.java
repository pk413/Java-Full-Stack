public class Employee {
private int id;
private String name;
private Address address;//Aggregation
//public Employee() {System.out.println("def cons");
public Employee(int id, String name, Address address) {
super();
this.id = id;
this.name = name;
this.address = address;
}
@Override
public String toString() {
	System.out.println("Employee==>"+id+"--"+name+"--"+address);
	return "Employee [id=" + id + ", name=" + name + ", address=" + address + "]";
}
}