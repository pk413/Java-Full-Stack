package spng_fact_meth_t3;

public class A implements Printable{
@Override
public void print() {
System.out.println("hello a");
}
}
