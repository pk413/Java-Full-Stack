package spng_fact_meth_t3;

public interface Printable {
void print();
}
